﻿namespace _10._11_orai;

internal class Program
{
    static void Main(string[] args)
    {
        haromszog haromszog1 = new haromszog(10,10,10);
        Console.WriteLine(haromszog1.HaromszogKeruleteP);
        //Console.WriteLine(haromszog1.HaromszogKeruleteM());
        Console.WriteLine(haromszog1.derekszoguM());
        Console.WriteLine("Nyomj le egy billentyűt a kilépéshez");
        Console.ReadKey();
    }
}
