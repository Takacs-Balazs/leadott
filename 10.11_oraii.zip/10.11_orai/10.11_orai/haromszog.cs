﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10._11_orai
{
    internal class haromszog
    {
        int aOldal;
        int bOldal;
        int cOldal;

        public haromszog () 
        { 
        }

        public haromszog(int aOldal, int bOldal, int cOldal)
        {
            this.aOldal = aOldal;
            this.bOldal = bOldal;
            this.cOldal = cOldal;
        }
        
        public int AOldal { get => aOldal; set => aOldal = value; }
        public int BOldal { get => bOldal; set => bOldal = value; }
        public int COldal { get => cOldal; set => cOldal = value; }

        bool szerkeszthetoM()
        {
            if (aOldal + BOldal > cOldal || bOldal + cOldal > aOldal || aOldal + cOldal > bOldal)
            {
                return true;
            }
            else return false;
        }
        bool szerkeszthetoP 
        {
            get 
            {
                if (aOldal + BOldal > cOldal || bOldal + cOldal > aOldal || aOldal + cOldal > bOldal) 
                {
                    return true;
                }
                else return false;
                
            }
        }

        public int HaromszogKeruleteP
        {
            get
            {
                if (szerkeszthetoP)
                {
                    return aOldal + bOldal + cOldal;
                }
                else 
                    return -1;


               
            }
        }

        public int haromszogKeruleteM()
        {
            if (szerkeszthetoM()) 
            {
                return bOldal + cOldal + cOldal;
            }
            else  
                return -1; 
               
        }
        public string derekszoguM()
        {
           int a = aOldal;
           int b = bOldal;
           int c = cOldal;

            if (a * a + b * b == c * c || b * b + c * c == a * a || a * a + c * c == b * b)
            {
                return "A háromszög derékszögű";
            }
            else return "A háromszög nem derékszögű";
            
        }

    }
}
