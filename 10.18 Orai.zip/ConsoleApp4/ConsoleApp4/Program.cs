﻿using System.Numerics;

const int elsoSzam = 4;
const int masodikszam = 4;
int[,] matrix = new int[elsoSzam, masodikszam];

for (int i = 0; i < elsoSzam; i++)
{
    for (int j = 0; j < masodikszam; j++)
    {
        matrix[i, j] = (i + 1) * 10 + (j + 1);
    }
}

for (int i = 0; i < elsoSzam; i++)
{
    int sorOsszeg = 0;
    for (int j = 0; j < masodikszam; j++)
    {
        Console.Write(matrix[i, j] + "\t");
        sorOsszeg += matrix[i, j];
    }
    Console.WriteLine(sorOsszeg);
}

for (int i = 0; i < masodikszam; i++)
{
    int oszlopOsszeg = 0;
    for (int j = 0; j < elsoSzam; j++)
    {
        oszlopOsszeg += matrix[j, i];
    }
    Console.Write(oszlopOsszeg + "\t");
}
Console.WriteLine();
int foatloOsszeg = 0;
for (int i = 0; i < elsoSzam; i++)
{
    foatloOsszeg += matrix[i, i];
}
Console.WriteLine($"Főátló összege: {foatloOsszeg}");


int mellekAtloOsszeg = 0;
for (int i = 0; i < elsoSzam; i++)
{
    mellekAtloOsszeg += matrix[i, 3 - i];
}
Console.WriteLine($"masodikszamellékátló összege: {mellekAtloOsszeg}");

int foatloFelettiElemekOsszege = 0;
for (int i = 0; i < masodikszam - 1; i++)
{
    for (int j = i + 1; j < masodikszam; j++)
    {
        foatloFelettiElemekOsszege += matrix[i, j];
    }
}
Console.WriteLine($"Főátló feletti elemek összege: {foatloFelettiElemekOsszege}");

int foatloAlattiElemekOsszege = 0;
for (int i = 1; i < masodikszam; i++)
{
    for (int j = 0; j < i; j++)
    {
        foatloAlattiElemekOsszege += matrix[i, j];
    }
}
Console.WriteLine($"Főátló alatti elemek összege: {foatloAlattiElemekOsszege}");

int mellekatlokOsszege = 0;
for (int i = 0; i < elsoSzam - 2; i++)
{
    for (int j = i + 1; j < masodikszam-2-i; j++)
    {
        mellekatlokOsszege += matrix[i, j];
    }
}
Console.WriteLine($"Mellékátló feletti elemek összege: {mellekatlokOsszege}");

int Mellekatloalatti = 0;
for (int i = 1; i < elsoSzam - 1; i++)
{
    for (int j = masodikszam-i + 1; j < masodikszam - 1; j++)
    {
        Mellekatloalatti += matrix[i, j];
    }
}
Console.WriteLine($"Mellekatlok alatti elemek összege: {Mellekatloalatti}");